import {Component,OnInit} from '@angular/core';
import {FormsModule,NgForm }  from '@angular/forms';
import {Employee} from './employee.component';
import {Myservice} from './myservice'
@Component({
    selector:"my-form",
    templateUrl:'./myform.component.html',
    providers :[Myservice]
})
export class MyForm implements OnInit{
    emp:Employee;
    emp2:number;
    searchResult:string = null;
    searchResultEmployee:Employee = null;
    empList:Employee[]=[];
    newEmpList:any[];
    constructor(private mser:Myservice){
        this.emp ={empNo:0,empName:"",salary:0,dept:""};
    }
    ngOnInit(){
        //this.empList= this.mser.getAllEmp();
        this.mser.getAllEmp().subscribe(result=>this.empList=result);
        this.mser.getFromSpring().subscribe(res=>this.newEmpList=res);
    }
    submitData(frm1:NgForm):void{
        let empno =frm1.controls['txtEmpNo'].value;
        let ename =frm1.controls['txtEmpName'].value;
        let sal =frm1.controls['txtSalary'].value;
        let dept =frm1.controls['txtDept'].value;
        let e = new Employee(empno,ename,sal,dept);
        this.empList.push(e);
        }
         id1(){
        this.empList.sort(function(a,b){return a.empNo-b.empNo});
        }
           id2(){
        this.empList.sort(function(a,b){
            if(a.empName<b.empName)
            return -1;
        else if(a.empName>b.empName)   
            return 1;   
            else return 0;
        });
        }
        
         id3(){
        this.empList.sort(function(a,b){return a.salary-b.salary});
        }
        
     id4(){
        this.empList.sort(function(a,b){
            if(a.dept<b.dept)
            return -1;
        else if(a.dept>b.dept)   
            return 1;   
            else return 0;
        });
        }
  deleteId(empNo:any){
  //console.log(empNo);
    for(var i=0;i<this.empList.length;i++)
    {
        if(this.empList[i]["empNo"]==empNo)    
  this.empList.splice(i,1);
  }
    }
  
    
    find(id:number):string{
        let yes:string = "This ID Exists";
        let no:string = "This ID does not Exist."
        
        let len:number = this.empList.length;
        let i:number = 0;
        let flag:number = 0;
        while(len!=0 && flag!=1)
        {
            if(this.empList[i].empNo == id){flag=1;}
            i++;
            len--;
        }
        
        
        if(flag==1){this.searchResultEmployee = this.empList[i-1]; return yes; }
        else {this.searchResultEmployee = null; return no;}
    }
    
    submitData2(frm2:NgForm):void{
        let id = frm2.controls['txtEmpNo2'].value;
        //this.empList.pop()
        console.log(this.find(id));
        this.searchResult = this.find(id);
    }
    
}